﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _05.MagicExchangableWorlds
{
    class CharPair
    {
        public char Key, Value;

        public CharPair(char key, char value)
        {
            Key = key;
            Value = value;
        }
    }
}
